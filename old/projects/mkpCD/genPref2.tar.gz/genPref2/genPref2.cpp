/**
 * Task Preferences Generator 
 *   - for N-resource, 0-1 knapsack problem
 *   - follows Bertisimas and Demir's specification
 *
 * Usage: genPref2 <M> <N> <A> <C> <mode> <tightness> <tag>
 *   - M: number of resources
 *   - N: number of tasks
 *   - A: resource requirement ~ U(1, A)
 *   - C: task value ~ U(1, C)
 *   - mode: 0 - uncorrelated, 1 - correlated
 *   - tightness: tightness of knapsack constraints (> 1.0)
 *   - tag: tag for output files
 *
 * Copyright (c) 2004 University of Michigan. All rights reserved.
 *
 * -----------------------------------------------------------------
 *
 * Author   :  Shih-Fen Cheng
 *
 * Purpose  :  Generating task preferences, output in general 
 *             format and ampl data file format.
 *
 * Created  :  2004.12.06
 */
#pragma warning (disable: 4786)
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include <vector>

#include "../common.h"

using namespace std;

int main(int argc, char** argv)
{
  if (argc < 8) {
    printf("usage: %s <number of resources> <number of tasks> <A> <C> <mode> <tightness constant> <common name>\n", argv[0]);
    printf("  - mode: 0 - uncorrelated, 1 - correlated\n");
    exit(0);
  }

  int i, j;
  time_t seed;
  time(&seed);
  srand(seed);

  int numResources = atoi(argv[1]);
  int numTasks = atoi(argv[2]);
  int A = atoi(argv[3]);
  int C = atoi(argv[4]);
  int mode = atoi(argv[5]);
  double alpha = atof(argv[6]);
  char pref_filename[80], data_filename[80], run_filename[80];
  char opt_filename[80], lp_run_filename[80], lp_opt_filename[80], dual_price_filename[80];
  sprintf(pref_filename, "%s.pref", argv[7]);
  sprintf(data_filename, "%s.data", argv[7]);
  sprintf(run_filename, "%s.run", argv[7]);
  sprintf(opt_filename, "%s.optimum", argv[7]);
  sprintf(lp_run_filename, "%s_lp.run", argv[7]);
  sprintf(lp_opt_filename, "%s.lp_optimum", argv[7]);
  sprintf(dual_price_filename, "%s.dual_price", argv[7]);

  // generating tasks
  vector<VI> vecTasks;
  VI vecTaskValues;

  for (i=0; i<numTasks; i++) {
    // resource requirement
    VI res(numResources+1);
    double cnt = 0.0;
    for (j=0; j<numResources; j++) {
      res[j] = d_uniform(1, A);
      cnt += res[j];
    }
    vecTasks.push_back(res);

    // value
    int v;
    if (mode==0) v = d_uniform(1, C);
    if (mode==1) v = (int)((cnt / (double)numResources) + (double)C*uniform(0, 1));
    vecTaskValues.push_back(v);
  }

  // generating resource capacities
  VL vecResources(numResources);
  for (i=0; i<numResources; i++) {
    long tot = 0;
    for (j=0; j<numTasks; j++) {
      tot += vecTasks[j][i];
    }
    vecResources[i] = (long)(tot * alpha);
  }

  // writing out general task preference descriptions
  FILE *fout = fopen(pref_filename, "w");
  //fprintf(fout, "numTasks %d\n", numTasks);
  //fprintf(fout, "numResources %d\n", numResources);
  fprintf(fout, "%d\n", numTasks);
  fprintf(fout, "%d\n", numResources);
  for (i=0; i<numTasks; i++) {
    //fprintf(fout, "pref %d", vecTaskValues[i]);
		fprintf(fout, "%d", vecTaskValues[i]);
    for (j=0; j<numResources; j++) {
      fprintf(fout, " %d", vecTasks[i][j]);
    }
    //fprintf(fout, " %d\n", vecTasks[i][numResources]);
    fprintf(fout, "\n");
  }
  //fprintf(fout, "holdings ");
  for (i=0; i<numResources; i++) {
    fprintf(fout, "%ld ", vecResources[i]);
  }
  fprintf(fout, "\n");
  fclose(fout);

	// write model specific file
  fout = fopen(data_filename, "w");
  WritePrefs(fout, vecTasks, vecTaskValues, numTasks, numResources);
  WriteHoldings(fout, vecResources, numResources);
  fclose(fout);

  // run file
  fout = fopen(run_filename, "w");
  fprintf(fout, "option solver cplex;\n");
  fprintf(fout, "model knapsack.model;\n");
  fprintf(fout, "data %s;\n", data_filename);
  fprintf(fout, "solve;\n");
  fprintf(fout, "printf \"%sd\\n\", util > %s;\n", "%", opt_filename);
  fprintf(fout, "for {t in Tasks} { printf \"%sd\", x[t] >> %s; }\n", "%", opt_filename);
  fclose(fout);

  // LP run file
  fout = fopen(lp_run_filename, "w");
  fprintf(fout, "option solver cplex;\n");
  fprintf(fout, "model knapsackLP.model;\n");
  fprintf(fout, "data %s;\n", data_filename);
  fprintf(fout, "solve;\n");
  fprintf(fout, "printf \"%sd\\n\", numResources > %s;\n", "%", dual_price_filename);
  fprintf(fout, "for {r in Resources} { printf \"%sf\\n\", R1[r].dual >> %s; }\n", "%", dual_price_filename);
  fprintf(fout, "printf \"%sd\\n\", util > %s;\n", "%", lp_opt_filename);
  fprintf(fout, "for {t in Tasks} { printf \"%sd\", x[t] >> %s; }\n", "%", lp_opt_filename);
  fclose(fout);

	return 0;
}
