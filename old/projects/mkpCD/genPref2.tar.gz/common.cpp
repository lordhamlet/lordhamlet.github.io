#pragma warning (disable: 4786)
#include <stdio.h>
#include <stdlib.h>

#include <vector>

#include "common.h"

using namespace std;

int d_uniform(int min, int max)
{ 
  return (min + rand() % (max-min+1));
}

long d_uniform(long min, long max)
{ 
  return (min + rand() % (max-min+1));
}

double uniform(double min, double max)
{
  return ( min + ( (double)rand()/(double)RAND_MAX )*(max-min) );
}

void loadPreference(char* filename, vector<VI>& tasks, VI& values, VL& holdings)
{
  int i, j;

  // load preferences & holdings from the file
  FILE *fin = fopen(filename, "r");
  if (fin == 0) {
    printf("ERROR: cannot open %s\n", filename);
    exit(-1);
  }

  int numTasks = 0;
  int numResources = 0;

  // get number of tasks
  fscanf(fin, "numTasks %d\n", &numTasks);
  // get number of resources
  fscanf(fin, "numResources %d\n", &numResources);
  
  // get tasks
  tasks.resize(numTasks);
  values.resize(numTasks);
  for (i=0; i<numTasks; i++) {
    fscanf(fin, "pref %d", &values[i]);
    tasks[i].resize(numResources);
    for (j=0; j<numResources; j++) {
      fscanf(fin, " %d", &tasks[i][j]);
    }
    fscanf(fin, "\n");
  }

  // get holdings
  holdings.resize(numResources);
  fscanf(fin, "holdings");
  for (i=0; i<numResources; i++) {
    fscanf(fin, " %ld", &holdings[i]);
  }
  fclose(fin);

}

void loadWeight(char* filename, vector<double>& w)
{
  // load preferences & holdings from the file
  FILE *fin = fopen(filename, "r");
  if (fin == 0) {
    printf("ERROR: cannot open %s\n", filename);
    exit(-1);
  }

  // get weights
  int num = 0;
  fscanf(fin, "%d\n", &num);
  ////
  //printf("%d\n", num);
  ////
  w.resize(num);
  for (int i=0; i<num; i++) {
    float f;
    fscanf(fin, "%f\n", &f);
    w[i] = f;
    ////
    //printf("%f\n", w[i]);
    ////
  }
  fclose(fin);
}

void printTasks(vector<VI>& tasks, VI& values) 
{
  for (unsigned int i=0; i<tasks.size(); i++) {
    printf("Task %2d (value=%4d):", i+1, values[i]);
    for (unsigned int j=0; j<tasks[i].size(); j++) {
      printf(" %2d", tasks[i][j]);
    }
    printf("\n");
  }
}

void printHoldings(VL& h) 
{
  unsigned int i;
  printf("Holdings: (");
  for (i=0; i<h.size(); i++) {
    printf("%ld ", h[i]);
  }
  printf(")\n");
}

int WritePrefs(FILE* fp, vector<VI>& tasks, VI& values, int nt, int nr)
{
  int i, j;

  if (NULL == fp) return 1;

  // write problem parameters
  fprintf(fp, "param numTasks %d;\n", nt);
  fprintf(fp, "param numResources %d;\n", nr);

  // write tasks' resoruces requirements
  fprintf(fp, "param TaskResReq\n");
  for (i=0; i<nt; i++) {
    for (j=0; j<nr; j++) {
      fprintf(fp, "[%2d, %2d] %d ", i+1, j+1, tasks[i][j]);
    }
    fprintf(fp, "\n");
  }
  fprintf(fp, ";\n");

  // write tasks' values
  fprintf(fp, "param TaskValue\n");
  for (i=0; i<nt; i++) {
    fprintf(fp, "[%2d] %4d ", i+1, values[i]);
    if ((i % 10)==9) fprintf(fp, "\n");
  }
  fprintf(fp, ";\n");

  return 0;
}

int WriteHoldings(FILE* fp, VL& h, int nr)
{
  int i;

  if (NULL == fp) return 1;

  // write total goods
  fprintf(fp, "param caps\n");
  for (i=0; i<nr; i++) {
    fprintf(fp, "[%2d] %4ld ", i+1, h[i]);
    if ((i % 10)==9) fprintf(fp, "\n");
  }
  fprintf(fp, ";\n");

  return 0;
}

void loadLPDec(char* filename, VI& dec, int nt) 
{
  // load rounded LP decision from given file
  FILE *fin = fopen(filename, "r");
  if (fin == 0) {
    printf("ERROR: cannot open %s\n", filename);
    exit(-1);
  }

  // get decisions
  char buf[100];
  fgets(buf, 100, fin);
  printf("LP optimum: %ld\n", atol(buf));

  if (dec.size() < (unsigned) nt) dec.resize(nt);
  for (int i=0; i<nt; i++) {
    char c = fgetc(fin);
    dec[i] = c - '0';
    ////
    //printf("%d", dec[i]);
  }
  fclose(fin);

}
