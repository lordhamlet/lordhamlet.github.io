#ifndef COMMON_H
#define COMMON_H
#pragma warning (disable: 4786)

#include <vector>

using namespace std;

inline int    ABS(const int x) { return (x < 0) ? -x : x; }
inline float  ABS(const float x) { return (x < 0) ? -x : x; }
inline double ABS(const double x) { return (x < 0) ? -x : x; }

inline int    MAX(const int x, const int y) { return (x > y) ? x : y; }
inline float  MAX(const float x, const float y) { return (x > y) ? x : y; }
inline double MAX(const double x, const double y) { return (x > y) ? x : y; }

typedef vector<int> VI;
typedef vector<long> VL;

// supporting function
int d_uniform(int min, int max);
double uniform(double min, double max);

void printTasks(vector<VI>& tasks, VI& values);
void printHoldings(VL& h);
void loadPreference(char* filename, vector<VI>& tasks, VI& values, VL& holdings);
void loadWeight(char* filename, vector<double>& w);
void loadLPDec(char* filename, VI& dec, int nt);

int WritePrefs(FILE* fp, vector<VI>& tasks, VI& values, int nt, int nr);
int WriteHoldings(FILE* fp, VL& h, int nr);

#endif
